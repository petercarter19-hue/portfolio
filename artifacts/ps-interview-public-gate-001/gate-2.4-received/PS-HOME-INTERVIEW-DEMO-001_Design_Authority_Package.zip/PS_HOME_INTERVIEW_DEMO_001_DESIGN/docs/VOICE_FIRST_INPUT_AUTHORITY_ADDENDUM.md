# Voice-First Input Authority Addendum

This addendum supersedes any Interview Studio mockup that presents written input as the only or default answer method.

1. **Voice is the default visual emphasis.** The first answer-method control is Voice and it receives the selected state at entry.
2. **Text is always visible.** Text is a peer answer method, not hidden behind advanced settings.
3. **One answer model.** Voice produces a reviewable transcript; Text edits the same answer object.
4. **One explicit submit action.** The answer is not sent for coaching until the member activates **Submit answer**.
5. **Homepage boundary.** The homepage walkthrough may display these controls but must not open a microphone, accept visitor input, call AI, or store anything.
6. **No fabricated delivery analysis.** Voice input does not imply pace, filler-word, confidence, eye-contact, or other analytics.
