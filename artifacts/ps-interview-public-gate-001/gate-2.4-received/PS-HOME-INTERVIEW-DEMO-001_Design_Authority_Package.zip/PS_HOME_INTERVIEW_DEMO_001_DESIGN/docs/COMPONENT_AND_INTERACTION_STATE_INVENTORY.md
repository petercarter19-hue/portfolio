# Component and Interaction-State Inventory

## Homepage scene components

| Component | Purpose | States |
|---|---|---|
| Narrative sequence rail | Places the scene between Living Résumé and My Story/Future | Interview Studio active |
| Editorial scene introduction | Explains voice-first practice and the illustrative boundary | Desktop, portrait, landscape |
| Four-step walkthrough rail | Question → Sample answer → Coaching review → Improved retry | Current, complete, future |
| Voice/Text answer-method switch | Makes Voice primary and Text always available | Voice selected; Text available |
| Voice preview stage | Explains the real Studio behavior without opening a microphone | Static illustrative state |
| Fictional voice transcript | Shows how a spoken answer becomes reviewable text | Fixed sample only |
| Submit sample answer | Advances to predetermined coaching | No AI or persistence |
| Bottom-line review | Leads with coaching conclusion | Fixed review |
| Framework map | Shows STAR completion and the result gap | Teal only for completed; marigold for improvement |
| Improved retry | Shows highlighted material change | Fixed retry |
| Final CTA | Opens `/interview-studio` | Normal link |
| Truth bar | Repeats the demonstration boundary | Persistent |

## Corrected full-Studio input references

- Voice is selected by default.
- Text is a peer alternative, not a hidden fallback.
- Voice produces a reviewable transcript.
- Both modes converge on one answer and one **Submit answer** action.
- Nothing is sent before Submit answer.
