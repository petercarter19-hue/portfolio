# Reduced-Motion Guidance

When `prefers-reduced-motion: reduce` is active:

1. Do not slide the editorial sheet or animate between the four states.
2. Do not pulse the microphone, animate the waveform, shimmer the review, or count up scores.
3. Replace state transitions immediately in place.
4. Move keyboard focus to the new state heading and announce the state once.
5. Preserve the four explicit step controls so the user can move directly.
6. Keep the final CTA and all truth labels unchanged.
