# Mapping to Approved Functional Direction

| Direction | Design allocation |
|---|---|
| Keep `/interview-studio` as the complete interactive page | Homepage CTA opens the real route; the walkthrough never replaces it |
| Show one realistic question | HOME-INTERVIEW-01 |
| Use a clearly fictional sample answer | HOME-INTERVIEW-02 labels the transcript fictional and illustrative |
| Bottom-line-first coaching | HOME-INTERVIEW-03 leads with the coaching conclusion |
| Show one improved retry | HOME-INTERVIEW-04 highlights the stronger result |
| Voice front and center; Text always available | Every question/answer state shows Voice selected and Text visible |
| Clear Submit answer in the real Studio | Two corrected full-Studio references show one explicit Submit answer action |
| No visitor submission or AI from homepage | Persistent truth labels and fixed predetermined states |
| No local or server storage | Truth bar and JavaScript-unavailable state |
| Pete framing remains separate | Homepage example contains no Pete identity; Studio correction retains Public demo profile labeling |
| Preserve global navigation | The design is an inserted scene and does not redesign the site navigation |
| JavaScript unavailable | Static question and a normal link to `/interview-studio` |
