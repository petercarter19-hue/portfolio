# Plain-English Owner Walkthrough

This homepage scene comes after the Living Résumé scene and before My Story/Future. It explains the next part of the PeerSlate story: after experience is captured and organized, a person can practice explaining it.

## State 1 — Question

The visitor sees one realistic leadership question. Voice is visually first, and Text is beside it. The page explains that these are the real Studio’s input choices, but the homepage does not open the microphone or accept an answer.

## State 2 — Sample answer

A fixed fictional answer appears as an illustrative voice transcript. It is not Pete’s answer and not the visitor’s. The visible Submit sample answer button demonstrates the real Studio’s required submit step while advancing only to predetermined coaching.

## State 3 — Coaching review

The bottom line comes first. The review shows what worked, what to improve, and where the answer sits in STAR. The Result stage is the one improvement target. No AI call or member history is involved.

## State 4 — Improved retry

The stronger result is highlighted so the visitor can see exactly what changed. The final primary action, “Practice this question in Interview Studio,” opens the real public `/interview-studio` page.

## Failure and accessibility behavior

With JavaScript unavailable, the homepage stays on the initial question and provides a normal link to Interview Studio. Keyboard focus is visible. Reduced-motion users get immediate state changes without sliding, fading, pulsing, or animated waveforms.

## What this does not authorize

It does not change the real Studio, repository, routes, AI, browser storage, camera behavior, authentication, or any backend system. It is design authority for the later `PS-HOME-INTERVIEW-DEMO-001` package only.
