# PS-HOME-INTERVIEW-DEMO-001 — Design Authority Package

**Status:** Design authority for a later, separate package. No production implementation authorized.  
**Visual authority:** Direction A — Editorial Studio Ledger.  
**Narrative placement:** Voice Capture → Living Résumé → Interview Studio → My Story & Future.

## Voice-first correction

Voice is the default and dominant answer method. Text remains equally available. The real Interview Studio answer state has one explicit **Submit answer** action. The homepage walkthrough shows the same model but never activates a microphone, sends visitor input, calls AI, or stores local state.

## Delivered mockups

- 4 desktop walkthrough states
- 4 mobile portrait states
- 4 mobile landscape states
- 2 keyboard-focus proofs
- 1 reduced-motion proof
- 1 JavaScript-unavailable proof
- 2 corrected full-Studio answer-method references

Total: **18 separate PNG mockups**.

## Truth boundary

The homepage scene uses a fixed fictional question, answer, coaching review, and retry. It creates no visitor draft, attempt, history, media, or server record. The final CTA is a normal link to `/interview-studio`.
