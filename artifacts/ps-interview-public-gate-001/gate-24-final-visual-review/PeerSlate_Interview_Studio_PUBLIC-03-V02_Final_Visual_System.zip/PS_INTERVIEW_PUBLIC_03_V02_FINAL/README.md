# PeerSlate Interview Studio — PUBLIC-03 through PUBLIC-V02

Controlling system: approved PUBLIC-01 and PUBLIC-02 visual system.

- Light theme: Editorial Studio Ledger.
- Dark theme: Cinematic Studio.
- Identical structure, content order, controls, and responsive behavior across themes.
- Separate desktop and mobile exports for every state.
- Static design source only; no production behavior.

## Exports

### PUBLIC-03 — Processing with answer preserved
- Desktop light: `desktop/light/PUBLIC-03_PROCESSING_ANSWER_PRESERVED_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-03_PROCESSING_ANSWER_PRESERVED_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-03_PROCESSING_ANSWER_PRESERVED_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-03_PROCESSING_ANSWER_PRESERVED_DARK_MOBILE.png`

### PUBLIC-04 — Bottom-line coaching review
- Desktop light: `desktop/light/PUBLIC-04_BOTTOM_LINE_COACHING_REVIEW_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-04_BOTTOM_LINE_COACHING_REVIEW_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-04_BOTTOM_LINE_COACHING_REVIEW_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-04_BOTTOM_LINE_COACHING_REVIEW_DARK_MOBILE.png`

### PUBLIC-05 — Interview AI and comparison
- Desktop light: `desktop/light/PUBLIC-05_INTERVIEW_AI_AND_COMPARISON_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-05_INTERVIEW_AI_AND_COMPARISON_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-05_INTERVIEW_AI_AND_COMPARISON_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-05_INTERVIEW_AI_AND_COMPARISON_DARK_MOBILE.png`

### PUBLIC-06 — Local Video Practice
- Desktop light: `desktop/light/PUBLIC-06_LOCAL_VIDEO_PRACTICE_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-06_LOCAL_VIDEO_PRACTICE_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-06_LOCAL_VIDEO_PRACTICE_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-06_LOCAL_VIDEO_PRACTICE_DARK_MOBILE.png`

### PUBLIC-07 — Browser-local History
- Desktop light: `desktop/light/PUBLIC-07_BROWSER_LOCAL_HISTORY_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-07_BROWSER_LOCAL_HISTORY_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-07_BROWSER_LOCAL_HISTORY_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-07_BROWSER_LOCAL_HISTORY_DARK_MOBILE.png`

### PUBLIC-V01 — Processing failure with retry
- Desktop light: `desktop/light/PUBLIC-V01_PROCESSING_FAILURE_RETRY_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-V01_PROCESSING_FAILURE_RETRY_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-V01_PROCESSING_FAILURE_RETRY_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-V01_PROCESSING_FAILURE_RETRY_DARK_MOBILE.png`

### PUBLIC-V02 — Camera/microphone denied with written fallback
- Desktop light: `desktop/light/PUBLIC-V02_CAMERA_MIC_DENIED_WRITTEN_FALLBACK_LIGHT_DESKTOP.png`
- Desktop dark: `desktop/dark/PUBLIC-V02_CAMERA_MIC_DENIED_WRITTEN_FALLBACK_DARK_DESKTOP.png`
- Mobile light: `mobile/light/PUBLIC-V02_CAMERA_MIC_DENIED_WRITTEN_FALLBACK_LIGHT_MOBILE.png`
- Mobile dark: `mobile/dark/PUBLIC-V02_CAMERA_MIC_DENIED_WRITTEN_FALLBACK_DARK_MOBILE.png`

## Truth boundaries

- Questions and answers are sent to PeerSlate only when submitted for coaching.
- Drafts, goals, attempts, and History are saved only in this browser.
- Video Practice remains local; media is not uploaded or analyzed.
- Scores are practice signals, not employer predictions.
- Pete Carter remains a public demo profile grounded only in his approved public résumé.

**Design only; implementation has not started.**